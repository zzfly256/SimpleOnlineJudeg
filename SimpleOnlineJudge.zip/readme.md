# Simple Online Judge

## 介绍
课设作品，暂时没啥好说的