<?php $__env->startSection('title'); ?>
    个人资料编辑
<?php $__env->stopSection(); ?>
<?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="empty" id="welcome">
    <?php if(Auth::user()): ?>
        <div class="columns col-oneline">
            <div class="column col-4">
                <div class="wecome-text">
                    <h2>欢迎您，<?php echo e(Auth::user()->name); ?></h2>
                    <h4>一套简易在线评测系统</h4>
                </div>
            </div>
            <div class="column col-8">
                <div class="welcome-panel user-edit">
                    <?php echo Form::model($user,['url'=>'/user','method'=>'PATCH']); ?>

                    <div class="form-group padding20">
                        <?php echo Form::label('用户名*',null,["class"=>"form-label"]); ?>

                        <?php echo Form::text('name',null,["class"=>"form-input"]); ?>

                        <?php echo Form::label('邮箱*',null,["class"=>"form-label"]); ?>

                        <?php echo Form::text('email',null,["class"=>"form-input"]); ?>

                        <?php echo Form::label('学校*',null,["class"=>"form-label"]); ?>

                        <?php echo Form::text('school',null,["class"=>"form-input"]); ?>

                        <?php echo Form::label('密码*',null,["class"=>"form-label"]); ?>

                        <?php echo Form::password('password',["class"=>"form-input", "placeholder"=>"若非修改，请勿填写"]); ?>

                    </div>

                    <div class="form-group margin20">
                        <?php echo Form::submit('确认修改',["class"=>"btn btn-default btn-width"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>

    <?php else: ?>
        <div class="columns col-oneline">
            <div class="column col-4">
                <div class="wecome-text">
                    <h2>Simple OJ</h2>
                    <h4>一套简易在线评测系统</h4>
                </div>
            </div>
            <div class="column col-8">

            </div>
        </div>
    <?php endif; ?>
</div>