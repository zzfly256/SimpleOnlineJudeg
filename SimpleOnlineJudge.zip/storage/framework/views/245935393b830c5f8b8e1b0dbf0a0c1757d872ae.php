<?php $__env->startSection('title'); ?>
    用户注册
<?php $__env->stopSection(); ?>
<?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="empty" id="welcome">
        <div class="columns col-oneline">
            <div class="column col-4">
                <div class="wecome-text">
                    <h2>Simple OJ</h2>
                    <h4>一套简易在线评测系统</h4>
                </div>
            </div>
            <div class="column col-8">
                <div class="welcome-panel user-edit">
                    <?php echo Form::open(['url'=>'/register']); ?>

                    <div class="form-group padding20">
                        <?php echo Form::label('用户名*',null,["class"=>"form-label"]); ?>

                        <?php echo Form::text('name',null,["class"=>"form-input"]); ?>

                        <?php echo Form::label('邮箱*',null,["class"=>"form-label"]); ?>

                        <?php echo Form::text('email',null,["class"=>"form-input"]); ?>

                        <?php echo Form::label('学校*',null,["class"=>"form-label"]); ?>

                        <?php echo Form::text('school',null,["class"=>"form-input"]); ?>

                        <?php echo Form::label('密码*',null,["class"=>"form-label"]); ?>

                        <?php echo Form::password('password',["class"=>"form-input"]); ?>

                        <?php echo Form::label('确认密码*',null,["class"=>"form-label"]); ?>

                        <?php echo Form::password('password_confirmation',["class"=>"form-input"]); ?>

                    </div>

                    <div class="form-group padding20">
                        <?php echo Form::submit('注册',["class"=>"btn btn-default btn-width"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>

</div>